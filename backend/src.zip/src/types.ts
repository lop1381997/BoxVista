export interface Objeto {
  id: string;
  nombre: string;
  state: string;
}

export interface Caja {
  id: number;
  name: string;
  description: string;
  objetos: Objeto[];
}