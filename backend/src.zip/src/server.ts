import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import boxesRouter from './routes/boxes.routes';
import objetosRouter from './routes/objects.routes';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

// ¡OJO! El path debe llevar la barra inicial
app.use('/api/boxes', boxesRouter);
// Montamos el router de objetos dentro de cada caja
app.use('/api/boxes/:boxId/objetos', objetosRouter);

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});