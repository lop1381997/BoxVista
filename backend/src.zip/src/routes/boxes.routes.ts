import { Router } from 'express';
import { Caja, Objeto } from '../types';
import { loadBoxes, saveBoxes } from '../storage';

const router = Router();

router.get('/', (req, res) => {
  const boxes = loadBoxes();
  res.json(boxes);
});

router.get('/:id', (req, res) => {
  const boxes = loadBoxes();
  const id = parseInt(req.params.id, 10);
  const box = boxes.find(b => b.id === id);
  if (!box) return res.status(404).json({ message: 'Caja no encontrada' });
  res.json(box);
});

router.post('/', (req, res) => {
  const boxes = loadBoxes();
  const { name, description, objetos } = req.body;
  const newId = boxes.length ? Math.max(...boxes.map(b => b.id)) + 1 : 1;

  const objetosConID = (objetos || []).map((obj: Partial<Objeto>, index: number) => ({
    ...obj,
    id: `${newId}-${index + 1}`,
  }));

  const nuevaCaja: Caja = {
    id: newId,
    name,
    description,
    objetos: objetosConID as Objeto[],
  };

  boxes.push(nuevaCaja);
  saveBoxes(boxes);
  res.status(201).json(nuevaCaja);
});

router.put('/:id', (req, res) => {
  const boxes = loadBoxes();
  const id = parseInt(req.params.id, 10);
  const index = boxes.findIndex(b => b.id === id);
  if (index === -1) return res.status(404).json({ message: 'Caja no encontrada' });

  boxes[index] = { ...boxes[index], ...req.body, id };
  saveBoxes(boxes);
  res.json(boxes[index]);
});

router.delete('/:id', (req, res) => {
  const boxes = loadBoxes();
  const id = parseInt(req.params.id, 10);
  const index = boxes.findIndex(b => b.id === id);
  if (index === -1) return res.status(404).json({ message: 'Caja no encontrada' });

  const deleted = boxes.splice(index, 1);
  saveBoxes(boxes);
  res.json(deleted[0]);
});

export default router;