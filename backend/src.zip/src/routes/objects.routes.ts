import { Router } from 'express';
import { Objeto } from '../types';
import { loadBoxes, saveBoxes } from '../storage';

const router = Router({ mergeParams: true }); // para leer req.params.boxId

// GET objetos de una caja
router.get('/', (req, res) => {
  const boxId = parseInt(req.params.boxId, 10);
  const boxes = loadBoxes();
  const box = boxes.find(b => b.id === boxId);
  if (!box) return res.status(404).json({ message: 'Caja no encontrada' });
  return res.json(box.objetos);
});

// POST añadir un objeto a la caja
router.post('/', (req, res) => {
  const boxId = parseInt(req.params.boxId, 10);
  const boxes = loadBoxes();
  const box = boxes.find(b => b.id === boxId);
  if (!box) return res.status(404).json({ message: 'Caja no encontrada' });

  const newIndex = box.objetos.length + 1;
  const newObjData = req.body as Omit<Objeto, 'id'>;
  const newObj: Objeto = {
    id: `${boxId}-${newIndex}`,
    ...newObjData,
  };

  box.objetos.push(newObj);
  saveBoxes(boxes);
  res.status(201).json(newObj);
});

// PUT actualizar un objeto existente
router.put('/:objId', (req, res) => {
  const boxId = parseInt(req.params.boxId, 10);
  const objId = req.params.objId;
  const boxes = loadBoxes();
  const box = boxes.find(b => b.id === boxId);
  if (!box) return res.status(404).json({ message: 'Caja no encontrada' });

  const idx = box.objetos.findIndex(o => o.id === objId);
  if (idx === -1) return res.status(404).json({ message: 'Objeto no encontrado' });

  const updated: Objeto = { ...box.objetos[idx], ...req.body, id: objId };
  box.objetos[idx] = updated;
  saveBoxes(boxes);
  res.json(updated);
});

// DELETE eliminar un objeto
router.delete('/:objId', (req, res) => {
  const boxId = parseInt(req.params.boxId, 10);
  const objId = req.params.objId;
  const boxes = loadBoxes();
  const box = boxes.find(b => b.id === boxId);
  if (!box) return res.status(404).json({ message: 'Caja no encontrada' });

  const idx = box.objetos.findIndex(o => o.id === objId);
  if (idx === -1) return res.status(404).json({ message: 'Objeto no encontrado' });

  const [deleted] = box.objetos.splice(idx, 1);
  saveBoxes(boxes);
  res.json(deleted);
});

export default router;